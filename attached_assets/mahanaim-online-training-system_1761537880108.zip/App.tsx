
import React, { useState, createContext, useEffect, useCallback } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import LandingPage from './pages/LandingPage';
import CoursesPage from './pages/CoursesPage';
import CourseDetailPage from './pages/CourseDetailPage';
import MyStatusPage from './pages/MyStatusPage';
import AdminPage from './pages/AdminPage';
import AuthPage from './pages/AuthPage';

import { User, Semester } from './types';
import { INITIAL_SEMESTERS } from './data';

interface AuthContextType {
    user: User | null;
    login: (email: string, pass: string) => void;
    logout: () => void;
    signup: (email: string, pass: string, name: string) => void;
    enrollCourse: (courseId: number) => void;
    unenrollCourse: (courseId: number) => void;
}

interface DataContextType {
    semesters: Semester[];
    setSemesters: React.Dispatch<React.SetStateAction<Semester[]>>;
}

export const AuthContext = createContext<AuthContextType>({} as AuthContextType);
export const DataContext = createContext<DataContextType>({} as DataContextType);

// Mock Users Database
const MOCK_USERS: User[] = [
    { id: '1', email: 'admin@mahanaim.com', name: '관리자', role: 'admin', enrolledCourses: [] },
    { id: '2', email: 'student@mahanaim.com', name: '학생', role: 'student', enrolledCourses: [101, 202] },
    { id: '3', email: 'kr.osyoo@gmail.com', name: '오서유', role: 'admin', enrolledCourses: [] },
];

const App: React.FC = () => {
    const [user, setUser] = useState<User | null>(null);
    const [semesters, setSemesters] = useState<Semester[]>(INITIAL_SEMESTERS);
    const navigate = useNavigate();

    const login = (email: string, pass: string) => {
        // NOTE: Password '1111' is not checked here as per mock setup, only email matters.
        const foundUser = MOCK_USERS.find(u => u.email === email);
        if (foundUser) {
            setUser(foundUser);
        } else {
            throw new Error('사용자를 찾을 수 없습니다.');
        }
    };
    
    const logout = () => {
        setUser(null);
        navigate('/');
    };
    
    const signup = (email: string, pass: string, name: string) => {
        if (MOCK_USERS.some(u => u.email === email)) {
            throw new Error('이미 사용중인 이메일입니다.');
        }
        const newUser: User = {
            id: String(MOCK_USERS.length + 1),
            email,
            name,
            role: 'student',
            enrolledCourses: [],
        };
        MOCK_USERS.push(newUser);
        setUser(newUser);
    };

    const enrollCourse = (courseId: number) => {
        setUser(currentUser => {
            if (!currentUser) return null;
            if (currentUser.enrolledCourses.includes(courseId)) return currentUser;
            return { ...currentUser, enrolledCourses: [...currentUser.enrolledCourses, courseId] };
        });
    };

    const unenrollCourse = (courseId: number) => {
        setUser(currentUser => {
            if (!currentUser) return null;
            return { ...currentUser, enrolledCourses: currentUser.enrolledCourses.filter(id => id !== courseId) };
        });
    };

    const authContextValue = { user, login, logout, signup, enrollCourse, unenrollCourse };
    const dataContextValue = { semesters, setSemesters };

    return (
        <AuthContext.Provider value={authContextValue}>
            <DataContext.Provider value={dataContextValue}>
                <div className="flex flex-col min-h-screen bg-gray-100 font-sans">
                    <Header />
                    <main className="flex-grow">
                        <Routes>
                            <Route path="/" element={<LandingPage />} />
                            <Route path="/courses" element={<CoursesPage />} />
                            <Route path="/course/:courseId" element={<CourseDetailPage />} />
                            <Route path="/my-status" element={<MyStatusPage />} />
                            <Route path="/admin" element={<AdminPage />} />
                            <Route path="/auth" element={<AuthPage />} />
                        </Routes>
                    </main>
                    <Footer />
                </div>
            </DataContext.Provider>
        </AuthContext.Provider>
    );
};

export default App;
