
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-dark mt-auto">
      <div className="container mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Mahanaim Online Training System. All rights reserved.</p>
          <p className="text-sm mt-1">A project for spiritual growth and discipleship.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
