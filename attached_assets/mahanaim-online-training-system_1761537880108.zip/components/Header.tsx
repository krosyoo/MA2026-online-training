
import React, { useState, useContext } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { AuthContext } from '../App';
import { HomeIcon, BookOpenIcon, UserCircleIcon, LoginIcon, LogoutIcon, MenuIcon, XIcon, VideoCameraIcon } from './Icons';

const Header: React.FC = () => {
    const { user, logout } = useContext(AuthContext);
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const navLinkClasses = "flex items-center px-3 py-2 text-sm font-medium rounded-md text-gray-300 hover:bg-brand-dark hover:text-white";
    const activeNavLinkClasses = "bg-brand-dark text-white";

    const navItems = [
        { to: "/", text: "홈", icon: <HomeIcon className="w-5 h-5 mr-2" /> },
        { to: "/courses", text: "전체 강의", icon: <VideoCameraIcon className="w-5 h-5 mr-2" /> },
    ];
    
    if (user) {
        navItems.push({ to: "/my-status", text: "나의 수강현황", icon: <UserCircleIcon className="w-5 h-5 mr-2" /> });
        if(user.role === 'admin') {
            navItems.push({ to: "/admin", text: "관리자", icon: <BookOpenIcon className="w-5 h-5 mr-2" /> });
        }
    }

    const NavLinks: React.FC<{ isMobile?: boolean }> = ({ isMobile = false }) => (
        <div className={isMobile ? "flex flex-col space-y-1 px-2 pt-2 pb-3" : "hidden md:flex items-center space-x-4"}>
            {navItems.map(item => (
                <NavLink
                    key={item.to}
                    to={item.to}
                    className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}
                    onClick={() => setIsMenuOpen(false)}
                >
                    {item.icon}
                    {item.text}
                </NavLink>
            ))}
            <div className="md:ml-4">
                {user ? (
                    <button onClick={() => { logout(); setIsMenuOpen(false); }} className={`${navLinkClasses} w-full md:w-auto`}>
                        <LogoutIcon className="w-5 h-5 mr-2" /> 로그아웃
                    </button>
                ) : (
                    <NavLink
                        to="/auth"
                        className={({ isActive }) => `${navLinkClasses} ${isActive ? activeNavLinkClasses : ''}`}
                        onClick={() => setIsMenuOpen(false)}
                    >
                        <LoginIcon className="w-5 h-5 mr-2" /> 로그인/가입
                    </NavLink>
                )}
            </div>
        </div>
    );

    return (
        <header className="bg-brand-primary shadow-lg sticky top-0 z-50">
            <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex items-center">
                        <Link to="/" className="flex-shrink-0 text-white flex items-center">
                            <BookOpenIcon className="w-8 h-8 mr-2 text-brand-accent"/>
                            <span className="text-xl font-bold">마하나임 온라인 훈련 시스템</span>
                        </Link>
                    </div>
                    <NavLinks />
                    <div className="-mr-2 flex md:hidden">
                        <button
                            onClick={() => setIsMenuOpen(!isMenuOpen)}
                            type="button"
                            className="bg-brand-dark inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-brand-primary focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-800 focus:ring-white"
                            aria-controls="mobile-menu"
                            aria-expanded="false"
                        >
                            <span className="sr-only">Open main menu</span>
                            {isMenuOpen ? (
                                <XIcon className="block h-6 w-6" aria-hidden="true" />
                            ) : (
                                <MenuIcon className="block h-6 w-6" aria-hidden="true" />
                            )}
                        </button>
                    </div>
                </div>
            </nav>
            {isMenuOpen && (
                <div className="md:hidden" id="mobile-menu">
                    <NavLinks isMobile={true} />
                </div>
            )}
        </header>
    );
};

export default Header;
