
import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { AuthContext, DataContext } from '../App';
import { Course } from '../types';

const MyStatusPage: React.FC = () => {
    const { user } = useContext(AuthContext);
    const { semesters } = useContext(DataContext);

    if (!user) {
        return (
            <div className="text-center py-20">
                <h1 className="text-2xl font-bold">로그인이 필요합니다.</h1>
                <Link to="/auth" className="text-brand-primary hover:underline mt-4 inline-block">로그인 페이지로 이동</Link>
            </div>
        );
    }

    const enrolledCourses: Course[] = semesters
        .flatMap(s => s.courses)
        .filter(c => user.enrolledCourses.includes(c.id));

    return (
        <div className="bg-gray-50 min-h-full">
            <div className="container mx-auto px-4 py-12">
                <div className="mb-10">
                    <h1 className="text-4xl font-extrabold text-brand-primary">나의 수강현황</h1>
                    <p className="mt-2 text-lg text-gray-600">{user.name}님의 수강중인 강의 목록입니다.</p>
                </div>

                {enrolledCourses.length > 0 ? (
                    <div className="bg-white p-8 rounded-xl shadow-lg">
                        <div className="divide-y divide-gray-200">
                            {enrolledCourses.map(course => {
                                const attendance = Math.floor(Math.random() * course.weeks) + 1; // Mock attendance
                                const progress = (attendance / course.weeks) * 100;

                                return (
                                <div key={course.id} className="py-6 flex flex-col md:flex-row items-center justify-between gap-4">
                                    <div className="flex-1">
                                        <Link to={`/course/${course.id}`} className="hover:underline">
                                            <h3 className="text-xl font-semibold text-brand-primary">{course.title}</h3>
                                        </Link>
                                        <p className="text-sm text-gray-500 mt-1">{course.instructor}</p>
                                    </div>
                                    <div className="w-full md:w-1/3">
                                        <div className="flex justify-between mb-1">
                                            <span className="text-base font-medium text-brand-secondary">출결 현황</span>
                                            <span className="text-sm font-medium text-brand-secondary">{attendance}/{course.weeks}주 ({Math.round(progress)}%)</span>
                                        </div>
                                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                                            <div className="bg-brand-accent h-2.5 rounded-full" style={{ width: `${progress}%` }}></div>
                                        </div>
                                    </div>
                                    <Link to={`/course/${course.id}`} className="px-4 py-2 bg-brand-secondary text-white font-semibold rounded-md hover:bg-brand-primary transition-colors text-sm whitespace-nowrap">
                                        강의실 입장
                                    </Link>
                                </div>
                                );
                            })}
                        </div>
                    </div>
                ) : (
                    <div className="text-center py-16 bg-white rounded-lg shadow-md">
                        <h2 className="text-2xl font-semibold text-gray-700">수강중인 강의가 없습니다.</h2>
                        <p className="mt-2 text-gray-500">관심있는 강의를 찾아보고 수강을 시작해보세요!</p>
                        <Link to="/courses" className="mt-6 inline-block px-6 py-3 bg-brand-primary text-white font-semibold rounded-lg shadow-md hover:bg-brand-dark transition-colors">
                            강의 목록 보러가기
                        </Link>
                    </div>
                )}
            </div>
        </div>
    );
};

export default MyStatusPage;
