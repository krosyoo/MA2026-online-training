
import React, { useContext, useState, useEffect } from 'react';
import { AuthContext, DataContext } from '../App';
import { Semester, Course } from '../types';

const AdminPage: React.FC = () => {
    const { user } = useContext(AuthContext);
    const { semesters, setSemesters } = useContext(DataContext);
    const [localSemesters, setLocalSemesters] = useState<Semester[]>([]);

    useEffect(() => {
        setLocalSemesters(JSON.parse(JSON.stringify(semesters)));
    }, [semesters]);
    
    if (user?.role !== 'admin') {
        return <div className="text-center py-20 text-red-500 font-bold">접근 권한이 없습니다.</div>;
    }

    const handleSemesterChange = (semesterId: number, field: keyof Semester, value: string) => {
        setLocalSemesters(prev => prev.map(s => s.id === semesterId ? { ...s, [field]: value } : s));
    };
    
    const handleCourseChange = (semesterId: number, courseId: number, field: keyof Course, value: string | number) => {
        setLocalSemesters(prev => prev.map(s => {
            if (s.id === semesterId) {
                return {
                    ...s,
                    courses: s.courses.map(c => c.id === courseId ? { ...c, [field]: value } : c)
                };
            }
            return s;
        }));
    };

    const handleSaveChanges = () => {
        setSemesters(localSemesters);
        alert('변경사항이 저장되었습니다.');
    };

    return (
        <div className="bg-gray-100 min-h-full">
            <div className="container mx-auto px-4 py-12">
                <h1 className="text-4xl font-extrabold text-brand-primary mb-8">관리자 대시보드</h1>
                
                <div className="bg-white p-8 rounded-xl shadow-lg">
                    <div className="flex justify-between items-center mb-6 pb-4 border-b">
                        <h2 className="text-2xl font-bold text-brand-dark">학기 및 강의 관리</h2>
                        <button 
                            onClick={handleSaveChanges}
                            className="px-6 py-2 bg-brand-primary text-white font-semibold rounded-lg shadow-md hover:bg-brand-dark transition-colors"
                        >
                            변경사항 저장
                        </button>
                    </div>
                    
                    <div className="space-y-8">
                        {localSemesters.map(semester => (
                            <div key={semester.id} className="border border-gray-200 p-6 rounded-lg">
                                <h3 className="text-xl font-semibold mb-4">학기 정보 수정</h3>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700">학기명</label>
                                        <input 
                                            type="text"
                                            value={semester.title}
                                            onChange={(e) => handleSemesterChange(semester.id, 'title', e.target.value)}
                                            className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700">학기 설명</label>
                                        <input 
                                            type="text"
                                            value={semester.description}
                                            onChange={(e) => handleSemesterChange(semester.id, 'description', e.target.value)}
                                            className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent"
                                        />
                                    </div>
                                </div>
                                <h4 className="text-lg font-semibold mt-6 mb-4">강의 목록</h4>
                                <div className="space-y-4">
                                    {semester.courses.map(course => (
                                        <div key={course.id} className="bg-gray-50 p-4 rounded">
                                            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                                                <input placeholder="강의명" value={course.title} onChange={(e) => handleCourseChange(semester.id, course.id, 'title', e.target.value)} className="w-full p-2 border rounded" />
                                                <input placeholder="강사" value={course.instructor} onChange={(e) => handleCourseChange(semester.id, course.id, 'instructor', e.target.value)} className="w-full p-2 border rounded" />
                                                <input placeholder="영상 URL" value={course.videoUrl} onChange={(e) => handleCourseChange(semester.id, course.id, 'videoUrl', e.target.value)} className="w-full p-2 border rounded" />
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AdminPage;
