import React, { useContext, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { DataContext, AuthContext } from '../App';
import { Course } from '../types';

const YoutubeEmbed: React.FC<{ url: string }> = ({ url }) => {
    const embedId = useMemo(() => {
        if (!url) return null;
        try {
            const urlObj = new URL(url);
            const listId = urlObj.searchParams.get('list');
            const videoIdFromParams = urlObj.searchParams.get('v');

            // Priority to playlist if URL path is specifically for a playlist
            if (listId && urlObj.pathname.includes('/playlist')) {
                return `videoseries?list=${listId}`;
            }
            
            // Handle standard /watch?v= links, including those part of a playlist
            if (videoIdFromParams) {
                return videoIdFromParams;
            }

            // Handle youtu.be short links
            if (urlObj.hostname === 'youtu.be') {
                const pathId = urlObj.pathname.slice(1);
                if (pathId) return pathId;
            }

            // Handle /shorts/ links
            if (urlObj.pathname.includes('/shorts/')) {
                const pathId = urlObj.pathname.split('/shorts/').pop();
                if (pathId) return pathId;
            }

            return null; // Return null if no valid ID is found
        } catch (e) {
            console.error("Invalid YouTube URL provided:", url, e);
            return null;
        }
    }, [url]);

    if (!embedId) {
        return (
            <div className="relative bg-gray-200 rounded-lg flex items-center justify-center" style={{ paddingTop: '56.25%' }}>
                <p className="absolute text-red-500 text-center font-semibold">유효하지 않거나 지원되지 않는 YouTube 영상 링크입니다.</p>
            </div>
        );
    }
    
    const embedUrl = `https://www.youtube.com/embed/${embedId}`;

    return (
        <div className="relative" style={{ paddingTop: '56.25%' }}>
            <iframe
                src={embedUrl}
                title="YouTube video player"
                frameBorder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="absolute top-0 left-0 w-full h-full rounded-lg"
            ></iframe>
        </div>
    );
};

const CourseDetailPage: React.FC = () => {
    const { courseId } = useParams<{ courseId: string }>();
    const { semesters } = useContext(DataContext);
    const { user, enrollCourse, unenrollCourse } = useContext(AuthContext);

    const course: Course | undefined = semesters
        .flatMap(s => s.courses)
        .find(c => c.id === parseInt(courseId || '0'));

    if (!course) {
        return (
            <div className="text-center py-20">
                <h1 className="text-2xl font-bold">강의를 찾을 수 없습니다.</h1>
                <Link to="/courses" className="text-brand-primary hover:underline mt-4 inline-block">강의 목록으로 돌아가기</Link>
            </div>
        );
    }
    
    const isEnrolled = user?.enrolledCourses.includes(course.id) ?? false;

    const handleEnrollment = () => {
        if (!user) {
            alert("로그인이 필요합니다.");
            return;
        }
        if (isEnrolled) {
            unenrollCourse(course.id);
        } else {
            enrollCourse(course.id);
        }
    }

    return (
        <div className="bg-gray-50">
            <div className="container mx-auto px-4 py-12">
                <div className="bg-white rounded-lg shadow-xl overflow-hidden">
                    <div className="p-6 md:p-8">
                        <h1 className="text-3xl md:text-4xl font-bold text-brand-dark">{course.title}</h1>
                        <p className="mt-2 text-lg text-gray-600">{course.weeks}주 과정 / 강사: {course.instructor}</p>
                    </div>

                    <div className="px-6 md:px-8 pb-8">
                        <YoutubeEmbed url={course.videoUrl} />
                    </div>

                    <div className="px-6 md:px-8 py-6 bg-brand-light border-t border-gray-200">
                        <h2 className="text-2xl font-semibold text-brand-primary mb-4">강의 정보</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div>
                                <h3 className="font-bold text-gray-700 mb-2">강의 안내</h3>
                                <p className="text-gray-600">{course.description}</p>
                                
                                <h3 className="font-bold text-gray-700 mt-6 mb-2">강의 자료</h3>
                                <div className="space-y-2">
                                    <a href="#" className="text-brand-secondary hover:underline">1주차 강의안.pdf</a>
                                    <a href="#" className="text-brand-secondary hover:underline block">2주차 참고자료.zip</a>
                                </div>
                            </div>
                             <div>
                                <h3 className="font-bold text-gray-700 mb-2">수강 신청</h3>
                                {user ? (
                                    <div className="p-4 bg-white rounded-lg border">
                                        <p className="mb-4">
                                            {isEnrolled ? '이미 수강 신청한 강의입니다.' : '이 강의를 수강하시겠습니까?'}
                                        </p>
                                        <button 
                                            onClick={handleEnrollment}
                                            className={`w-full px-6 py-3 font-semibold rounded-lg text-white transition-colors ${isEnrolled ? 'bg-red-600 hover:bg-red-700' : 'bg-brand-primary hover:bg-brand-dark'}`}
                                        >
                                            {isEnrolled ? '수강 취소' : '수강 신청하기'}
                                        </button>
                                    </div>
                                ) : (
                                    <div className="p-4 bg-yellow-100 text-yellow-800 rounded-lg">
                                        <p>강의를 신청하려면 <Link to="/auth" className="font-bold underline">로그인</Link>이 필요합니다.</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CourseDetailPage;