
import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { DataContext } from '../App';
import { Book } from '../types';

const BookCard: React.FC<{ book: Book, isHighlighted?: boolean }> = ({ book, isHighlighted = false }) => (
    <div className={`bg-white rounded-lg shadow-md overflow-hidden transform hover:-translate-y-1 transition-transform duration-300 ${isHighlighted ? 'border-2 border-brand-accent' : ''}`}>
        <img 
            src={`https://picsum.photos/seed/${book.title.replace(/\s/g, '')}/400/600`} 
            alt={book.title} 
            className="w-full h-48 object-cover" 
        />
        <div className="p-4">
            <h4 className="font-bold text-md text-gray-800 truncate" title={book.title}>{book.title}</h4>
            <p className="text-sm text-gray-600">{book.publisher}</p>
            <a 
                href={book.link} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="mt-3 inline-block bg-brand-secondary text-white text-xs px-3 py-1 rounded-full hover:bg-brand-primary transition-colors"
            >
                자세히 보기
            </a>
        </div>
    </div>
);

const LandingPage: React.FC = () => {
    const { semesters } = useContext(DataContext);

    return (
        <div className="bg-brand-light">
            <div className="container mx-auto px-4 py-8 sm:py-16">
                {/* Hero Section */}
                <div className="text-center mb-12 sm:mb-20">
                    <h1 className="text-4xl sm:text-6xl font-extrabold text-brand-primary tracking-tight">마하나임 온라인 훈련 시스템</h1>
                    <p className="mt-4 max-w-2xl mx-auto text-lg sm:text-xl text-gray-600">
                        체계적인 커리큘럼을 통해 신앙의 성장을 경험하고, 세상 속에서 빛과 소금의 역할을 감당하는 그리스도의 제자로 세워져 가세요.
                    </p>
                    <div className="mt-8 flex justify-center gap-4">
                        <Link to="/courses" className="px-8 py-3 bg-brand-primary text-white font-semibold rounded-lg shadow-md hover:bg-brand-dark transition-all duration-300 text-lg">
                            강의 둘러보기
                        </Link>
                        <Link to="/auth" className="px-8 py-3 bg-white text-brand-primary font-semibold rounded-lg shadow-md hover:bg-gray-100 transition-all duration-300 text-lg">
                            회원가입
                        </Link>
                    </div>
                </div>

                {/* Semesters & Books Section */}
                <div>
                    {semesters.map((semester, index) => (
                        <section key={semester.id} className={`py-12 px-6 rounded-2xl ${index % 2 === 0 ? 'bg-white' : 'bg-brand-light'}`}>
                            <div className="text-center mb-10">
                                <h2 className="text-3xl font-bold text-brand-dark">{semester.title}</h2>
                                <p className="text-md text-gray-500 mt-1">{semester.description}</p>
                            </div>
                            
                            <h3 className="text-xl font-semibold text-gray-700 mb-4 border-l-4 border-brand-accent pl-3">학기별 추천 도서</h3>
                            
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
                                <div>
                                    <h4 className="font-bold text-lg mb-3 text-brand-primary">강의 도서 (1권)</h4>
                                    <BookCard book={semester.books.courseBook} isHighlighted />
                                </div>
                                <div className="md:col-span-2">
                                    <h4 className="font-bold text-lg mb-3 text-brand-primary">필수 도서 (1권)</h4>
                                    <BookCard book={semester.books.requiredBook} isHighlighted />
                                </div>
                            </div>

                            <div>
                                <h4 className="font-bold text-lg mb-3 text-brand-secondary">추천 도서 (5권)</h4>
                                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
                                    {semester.books.recommendedBooks.map(book => (
                                        <BookCard key={book.title} book={book} />
                                    ))}
                                </div>
                            </div>
                        </section>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default LandingPage;
