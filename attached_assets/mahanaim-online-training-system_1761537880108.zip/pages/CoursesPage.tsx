
import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { DataContext } from '../App';
import { VideoCameraIcon } from '../components/Icons';

const CoursesPage: React.FC = () => {
    const { semesters } = useContext(DataContext);

    return (
        <div className="bg-gray-50 min-h-full">
            <div className="container mx-auto px-4 py-12">
                <div className="text-center mb-12">
                    <h1 className="text-4xl font-extrabold text-brand-primary">전체 강의 목록</h1>
                    <p className="mt-3 text-lg text-gray-600">믿음의 여정을 시작하고, 각 단계에 맞는 훈련을 통해 성장하세요.</p>
                </div>

                <div className="space-y-12">
                    {semesters.map((semester) => (
                        <div key={semester.id} className="bg-white p-8 rounded-xl shadow-lg border border-gray-200">
                            <div className="mb-6 pb-4 border-b border-gray-200">
                                <h2 className="text-3xl font-bold text-brand-dark">{semester.title}</h2>
                                <p className="text-md text-gray-500 mt-1">{semester.description}</p>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {semester.courses.map((course) => (
                                    <Link 
                                        to={`/course/${course.id}`} 
                                        key={course.id}
                                        className="block bg-brand-light p-6 rounded-lg hover:shadow-xl hover:bg-blue-100 transition-all duration-300"
                                    >
                                        <div className="flex items-start">
                                            <div className="flex-shrink-0">
                                                <VideoCameraIcon className="w-8 h-8 text-brand-accent" />
                                            </div>
                                            <div className="ml-4">
                                                <h3 className="text-xl font-semibold text-brand-primary">{course.title}</h3>
                                                <p className="text-sm text-gray-600 mt-1">{course.weeks}주 과정</p>
                                                <p className="text-sm text-gray-700 mt-2">{course.description}</p>
                                                <span className="mt-4 inline-block text-sm font-medium text-brand-secondary">강의 보기 &rarr;</span>
                                            </div>
                                        </div>
                                    </Link>
                                ))}
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default CoursesPage;
